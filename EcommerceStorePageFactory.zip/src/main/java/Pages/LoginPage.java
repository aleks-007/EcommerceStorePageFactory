package Pages;

import BasePage.BasePage;
import Helpers.WaitHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.Assert;

public class LoginPage extends BasePage {

    @FindBy(id="log") public WebElement username;
    @FindBy(how = How.ID, using = "pwd") public WebElement password;
    @FindBy(how = How.ID, using = "rememberme") public WebElement checkbox;
    @FindBy(how = How.ID, using = "login") public WebElement login_button;


    public LoginPage(WebDriver driver) {
        super(driver);
    }

    public LoginPage enterLoginDate(String user, String pass) {

        username.sendKeys(user);
        password.sendKeys(pass);
        checkbox.click();
        login_button.click();
        return new LoginPage(driver);
    }
    public  LoginPage showYourAccount(){

        Assert.assertEquals("Your Account | ONLINE STORE", driver.getTitle());
        return new LoginPage(driver);
    }
    public LoginPage showIsPasswordInvalid()   {
        WaitHelper.waitUntilElementISVisible(driver, By.xpath("(//p[@class='response'])[1]"), 10);
        Assert.assertTrue(driver.findElement(By.xpath("(//p[@class='response'])[1]")).getText().contains("is incorrect"));
        return new LoginPage(driver);
    }
    public LoginPage showIsCredentialInvalid() {
        WaitHelper.waitUntilElementISVisible(driver, By.cssSelector("p[class='response']"), 10);
        Assert.assertTrue(driver.findElement(By.cssSelector("p[class='response']")).getText().contains("enter your username"));
        return new LoginPage(driver);
    }
    public LoginPage showIsUsernameInvalid(){
        WaitHelper.waitUntilElementISVisible(driver, By.cssSelector("p[class='response']"), 10);
        Assert.assertTrue(driver.findElement(By.cssSelector("p[class='response']")).getText().contains("Invalid username"));
        return new LoginPage(driver);
    }
}