package Tests;

import BaseTest.BaseTest;
import Helpers.PropertiesReader;
import Pages.CheckoutPage;
import Pages.ProductCategory;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;

public class CheckoutSteps extends BaseTest {
    CheckoutPage checkoutPage;
    ProductCategory productCategory;

    PropertiesReader propertyReader = PageFactory.initElements(driver, PropertiesReader.class);

    String numberOfProducts = propertyReader.getProperty("productsNumber");


    public CheckoutSteps() throws IOException {
    }

    @BeforeMethod
    public void initializePageObjects(){
        checkoutPage = PageFactory.initElements(driver, CheckoutPage.class);
        productCategory = PageFactory.initElements(driver, ProductCategory.class);
    }
    // Happy Flow buying products without login to the site.
    // First go to product page, then checkout page, then checkout form.
    @Test
    public void checkoutWithValidInformation() throws InterruptedException {
        productCategory.navigateToProductCategoryPage();
        productCategory.addProducts();
        checkoutPage.navigateToCheckoutPage();
        checkoutPage.areElementsVisible();
        checkoutPage.updateQuantityOfFirstProduct(numberOfProducts);
        checkoutPage.clickUpdateButton(numberOfProducts);
        checkoutPage.removeProduct2();
        checkoutPage.clickContinueButton();
        checkoutPage.showCheckoutForm();

        //Filling checkout form




    }
}
