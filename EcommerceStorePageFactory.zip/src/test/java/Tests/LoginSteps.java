package Tests;

import BaseTest.BaseTest;
import Helpers.PropertiesReader;
import Pages.LoginPage;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;

public class LoginSteps extends BaseTest {

    LoginPage loginPage;
    PropertiesReader propertyReader = PageFactory.initElements(driver, PropertiesReader.class);

    String user = propertyReader.getProperty("username");
    String pass = propertyReader.getProperty("password");
    String invalid_pass = propertyReader.getProperty("invalid_password");
    String invalid_user = propertyReader.getProperty("invalid_username");

    public LoginSteps() throws IOException {
    }

    @BeforeMethod
    public void initializePageObjects(){
        loginPage = PageFactory.initElements(driver, LoginPage.class);
    }

    @Test
    public void loginWithValidCredentials()   {
        loginPage.navigateToMyAccountPage();
        loginPage.enterLoginDate(user, pass);
        loginPage.showYourAccount();
    }
    @Test
    public void loginWithInvalidPassword()  {
        loginPage.navigateToMyAccountPage();
        loginPage.enterLoginDate(user, invalid_pass);
        loginPage.showIsPasswordInvalid();
    }
    @Test
    public void loginWithNoCredentials()  {
        loginPage.navigateToMyAccountPage();
        loginPage.enterLoginDate("","");
        loginPage.showIsCredentialInvalid();
    }
   @Test
    public void loginWithInvalidUsername() {
        loginPage.navigateToMyAccountPage();
        loginPage.enterLoginDate(invalid_user, pass);
        loginPage.showIsUsernameInvalid();
    }
}