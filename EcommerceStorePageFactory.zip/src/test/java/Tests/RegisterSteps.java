package Tests;

import BaseTest.BaseTest;
import Helpers.PropertiesReader;
import Pages.RegisterPage;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;

public class RegisterSteps extends BaseTest {

    RegisterPage registerPage;
    PropertiesReader propertyReader = PageFactory.initElements(driver, PropertiesReader.class);

    String new_username = propertyReader.getProperty("new_user");
    String new_email = propertyReader.getProperty("email");

    public RegisterSteps() throws IOException {
    }

    @BeforeMethod
    public void initializeRegisterObjects(){
        registerPage = PageFactory.initElements(driver, RegisterPage.class);
    }

    @Test
    public void userNameAcceptableChar() {
        registerPage.navigateToMyAccountPage();
        registerPage.navigateToRegisterPage();
        registerPage.enterRegisterCredentials(new_username, new_email);
        registerPage.showIsRegistrationComplete();
    }
}